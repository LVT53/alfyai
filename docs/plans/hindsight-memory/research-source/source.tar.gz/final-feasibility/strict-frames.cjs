const fs=require('fs'),{project}=require('./frames-strict.cjs');
const all=[...JSON.parse(fs.readFileSync(__dirname+'/cases.json')),...JSON.parse(fs.readFileSync(__dirname+'/fresh-frames-frozen.json')).cases];
const cases=all.filter(c=>['different_projects','quote_hu','phone_reassignment','shopping'].includes(c.id));
fs.writeFileSync(__dirname+'/strict-frames-frozen.json',JSON.stringify({cases,strictSchema:true,reasoning:false,maxOutput:3500},null,2));
(async()=>{const out=[];for(const c of cases){let r;try{r=await project(c)}catch(e){r={accepted:false,error:e.message}}out.push({...c,...r});fs.writeFileSync(__dirname+'/strict-frames-results.json',JSON.stringify(out,null,2));console.log(c.id,JSON.stringify(r));}})();
