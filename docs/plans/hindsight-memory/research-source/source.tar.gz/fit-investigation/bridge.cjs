// Read-only configuration; only synthetic inference requests. No remote writes.
const fs = require('node:fs');
const crypto = require('node:crypto');
const readline = require('node:readline');
process.loadEnvFile('.env');
const Database = require('better-sqlite3');
const db = new Database(process.env.DATABASE_PATH || './data/chat.db', { readonly: true });
const records=db.prepare('select p.base_url,p.api_key_encrypted,p.api_key_iv,m.name from providers p join provider_models m on m.provider_id=p.id where m.name in (?,?)').all('qwen3-6-27b','accounts/fireworks/models/kimi-k3p1-pro');
db.close();
const rows=new Map();
for(const row of records){let key=row.api_key_encrypted;if(row.api_key_iv){const derived=crypto.pbkdf2Sync(process.env.SESSION_SECRET,'alfyai-providers',100000,32,'sha256'),raw=Buffer.from(key,'base64'),decipher=crypto.createDecipheriv('aes-256-gcm',derived,Buffer.from(row.api_key_iv,'base64'));decipher.setAuthTag(raw.subarray(-16));key=decipher.update(raw.subarray(0,-16)).toString('utf8')+decipher.final('utf8');}rows.set(row.name,{...row,key});}
readline.createInterface({input:process.stdin}).on('line',async line=>{const req=JSON.parse(line),start=Date.now();try{const row=rows.get(req.body.model);if(!row || row.name!=='qwen3-6-27b')throw Error('Only local model permitted for remaining tests');const payload={...req.body,stream:false};if(row.name==='qwen3-6-27b')payload.chat_template_kwargs={enable_thinking:req.body.chat_template_kwargs?.enable_thinking===true};const r=await fetch(row.base_url.replace(/\/$/,'')+'/chat/completions',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+row.key},body:JSON.stringify(payload),signal:AbortSignal.timeout(180000)});console.log(JSON.stringify({id:req.id,status:r.status,body:await r.json(),ms:Date.now()-start}));}catch(e){console.log(JSON.stringify({id:req.id,status:500,body:{error:e.message}}));}});
