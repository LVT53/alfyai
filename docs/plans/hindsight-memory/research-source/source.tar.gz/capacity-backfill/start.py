import os
from pathlib import Path
root=Path('/tmp/alfyai-hindsight-eval')
settings={'PG0_HOME':str(root/'pg0'),'PG0_INSTALLATION_DIR':str(root/'pg-install'),'HF_HOME':str(root/'hf'),'HINDSIGHT_API_DATABASE_URL':'pg0://alfyai-eval','HINDSIGHT_API_LLM_PROVIDER':'openai','HINDSIGHT_API_LLM_MODEL':'qwen3-6-27b','HINDSIGHT_API_LLM_API_KEY':'synthetic-local-proxy','HINDSIGHT_API_LLM_BASE_URL':'http://127.0.0.1:18891/v1','HINDSIGHT_API_EMBEDDINGS_PROVIDER':'onnx','HINDSIGHT_API_RERANKER_PROVIDER':'flashrank','HINDSIGHT_API_RERANKER_FLASHRANK_MODEL':'ms-marco-MultiBERT-L-12','HINDSIGHT_API_RERANKER_FLASHRANK_CACHE_DIR':str(root/'reranker')}
settings.update({'HINDSIGHT_API_TENANT_EXTENSION':'hindsight_ext_static_keys_tenant:StaticKeysTenantExtension','HINDSIGHT_API_TENANT_USERS':','.join(f'p{i:02}:synthetic-v2-p{i:02}' for i in range(1,7)),'HINDSIGHT_API_TENANT_SCHEMA_PREFIX':'adoption','PYTHONPATH':str(root/'source/hindsight-extensions/static-keys-tenant')})
settings['HINDSIGHT_API_HTTP_EXTENSION']='native_delete:NativeDelete'
settings['PYTHONPATH']='/tmp/alfyai-hindsight-readiness:'+settings['PYTHONPATH']
settings['HINDSIGHT_API_RETAIN_LLM_EXTRA_BODY']='{"chat_template_kwargs":{"enable_thinking":true},"max_tokens":8192}'
os.environ.update(settings)
cmd=str(root/'venv/bin/hindsight-api')
os.execv(cmd,[cmd,'--host','127.0.0.1','--port','18890'])
