"""Summarize frozen synthetic capacity evidence; no model or database calls."""
import collections
import json
import pathlib
import statistics

root = pathlib.Path(__file__).resolve().parent
run = json.loads((root / 'results.json').read_text())
growth = json.loads((root / 'growth-results.json').read_text())
calls = [json.loads(line) for line in (root / 'model-calls.jsonl').read_text().splitlines()]
assert run.get('finished') and not run.get('error')
assert growth.get('finished') and not growth.get('error')
summary = {'phases': [], 'foreground': {}}
for phase in run['phases'] + growth['phases']:
    selected = [c for c in calls if c.get('kind') == 'background' and phase['start'] <= c['startedAt'] < phase['end']]
    rows = phase['result'].get('native', phase['result']).get('items', [])
    summary['phases'].append({
        'name': phase['name'], 'seconds': phase['ms'] / 1000,
        'modelCalls': len(selected),
        'nativeDedupCalls': sum('_DedupDecision' in json.dumps(c['request']) for c in selected),
        'promptTokens': sum(c['response']['body'].get('usage', {}).get('prompt_tokens', 0) for c in selected),
        'completionTokens': sum(c['response']['body'].get('usage', {}).get('completion_tokens', 0) for c in selected),
        'statuses': dict(collections.Counter(c['response']['status'] for c in selected)),
        'finishReasons': dict(collections.Counter(choice.get('finish_reason') for c in selected for choice in c['response']['body'].get('choices', []))),
        'nativeRows': dict(collections.Counter(row['fact_type'] for row in rows))
    })
for group in ['baseline', 'loaded', 'after']:
    probes = [p for p in run['probes'] if (p['label'] not in ['baseline', 'after'] if group == 'loaded' else p['label'] == group)]
    assert all(p.get('status') == 200 and not p.get('error') for p in probes)
    values = sorted(p['ms'] for p in probes)
    summary['foreground'][group] = {'n': len(values), 'medianMs': statistics.median(values), 'maxMs': max(values)}
inventory = json.loads((root / 'inventory.json').read_text())
phases = {p['name']: p for p in summary['phases']}
seconds_per_message = (phases['retain-short-16']['seconds'] + statistics.mean([phases['consolidate-one-short']['seconds'], phases['consolidate-one-short-repeat']['seconds']])) / 16
summary['extrapolation'] = {
    'assumption': 'Synthetic short-message seconds per message, linear; planning allowance is twice this. Not measured production duration.',
    'secondsPerMessage': seconds_per_message,
    'users': [{'label': u['label'], 'messages': u['userText']['count'], 'linearMinutes': u['userText']['count'] * seconds_per_message / 60} for u in inventory['users']],
    'totalHours': sum(u['userText']['count'] for u in inventory['users']) * seconds_per_message / 3600,
    'routineMinutesPerDay': sum(u['last7DaysUser']['count'] for u in inventory['users']) / 7 * seconds_per_message / 60
}
(root / 'analysis.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
