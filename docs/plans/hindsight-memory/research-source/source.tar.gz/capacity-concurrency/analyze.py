"""Offline concurrency phase metrics; all comparison inputs are synthetic."""
import collections
import json
import pathlib

root = pathlib.Path(__file__).resolve().parent
run = json.loads((root / 'results.json').read_text())
calls = [json.loads(line) for line in (root / 'model-calls.jsonl').read_text().splitlines()]
assert run.get('finished') and not run.get('error')
summary = []
baseline = run['cases'][0]['ms']
for case in run['cases']:
    result = {'limit': case['limit'], 'seconds': case['ms'] / 1000,
              'speedup': baseline / case['ms'],
              'linearBackfillHours': 2104 * case['ms'] / 24 / 3600000,
              'phases': []}
    for phase in case['phases']:
        selected = [c for c in calls if phase['start'] <= c['startedAt'] < phase['end']]
        points = sorted([(c['startedAt'], 1) for c in selected] + [(c['finishedAt'], -1) for c in selected])
        current = peak = 0
        for _, delta in points:
            current += delta
            peak = max(peak, current)
        result['phases'].append({
            'name': phase['name'], 'seconds': phase['ms'] / 1000,
            'calls': len(selected), 'peakObservedConcurrency': peak,
            'nativeDedupCalls': sum('_DedupDecision' in json.dumps(c['request']) for c in selected),
            'statuses': dict(collections.Counter(c['response']['status'] for c in selected)),
            'finishReasons': dict(collections.Counter(ch.get('finish_reason') for c in selected for ch in c['response']['body'].get('choices', []))),
            'promptTokens': sum(c['response']['body'].get('usage', {}).get('prompt_tokens', 0) for c in selected),
            'completionTokens': sum(c['response']['body'].get('usage', {}).get('completion_tokens', 0) for c in selected),
            'rowsPerBank': [dict(collections.Counter(x['fact_type'] for x in bank['items'])) for bank in phase['result']]
        })
    summary.append(result)
(root / 'analysis.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
