// Throwaway local-model concurrency transport; no production configuration changes.
const fs=require('node:fs'),http=require('node:http'),cp=require('node:child_process'),rl=require('node:readline');
const script=fs.readFileSync(__dirname+'/../capacity-backfill/bridge.cjs','utf8'),quote=s=>"'"+s.replaceAll("'","'\\''")+"'";
const child=cp.spawn('ssh',['-o','BatchMode=yes','-o','RequestTTY=no','-o','RemoteCommand=none','alfydesign','cd /home/alfydesign/apps/langflow-chat/current && node -e '+quote(script)],{stdio:['pipe','pipe','inherit']});
let seq=0,active=0,limit=1;const pending=new Map(),queue=[];
function send(p){p.startedAt=Date.now();active++;child.stdin.write(JSON.stringify({id:p.id,body:p.body})+'\n')}
function drain(){while(active<limit&&queue.length)send(queue.shift())}
rl.createInterface({input:child.stdout}).on('line',line=>{let r;try{r=JSON.parse(line)}catch{return}const p=pending.get(r.id);if(!p)return;pending.delete(r.id);active--;const finishedAt=Date.now();fs.appendFileSync(__dirname+'/model-calls.jsonl',JSON.stringify({limit,request:p.body,response:r,receivedAt:p.receivedAt,startedAt:p.startedAt,finishedAt,queueMs:p.startedAt-p.receivedAt})+'\n');p.res.writeHead(r.status,{'Content-Type':'application/json'});p.res.end(JSON.stringify(r.body));drain()});
http.createServer(async(req,res)=>{let text='';for await(const part of req)text+=part;try{
if(req.url==='/capacity-control'){const b=JSON.parse(text);if(active||queue.length||!Number.isInteger(b.limit)||b.limit<1||b.limit>12)throw Error('Control requires idle proxy and limit 1..12');limit=b.limit;res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({limit}));return}
const body=JSON.parse(text),id=++seq,p={id,body,res,receivedAt:Date.now()};pending.set(id,p);queue.push(p);drain();
}catch(e){res.writeHead(400);res.end(JSON.stringify({error:e.message}))}}).listen(18891,'127.0.0.1',()=>console.log('Concurrency proxy ready'));
process.on('SIGTERM',()=>{child.kill();process.exit()});
