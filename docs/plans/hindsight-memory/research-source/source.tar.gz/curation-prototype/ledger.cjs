// THROWAWAY single-process state model. No production/distributed durability claim.
const fs=require('fs');
class Ledger {
 constructor(path){this.path=path;this.state=fs.existsSync(path)?JSON.parse(fs.readFileSync(path)):{};}
 save(){fs.writeFileSync(this.path+'.tmp',JSON.stringify(this.state,null,2));fs.renameSync(this.path+'.tmp',this.path);}
 user(id){return this.state[id]??={revision:0,sources:{},edits:[],bank:null,publishedRevision:-1};}
 ingest(user,id,version,text){const u=this.user(user),old=u.sources[id];if(old&&version<old.version)return 'stale';if(old&&version===old.version){if(old.text!==text)throw Error('same source version has different content');return 'duplicate';}u.sources[id]={version,text};u.revision++;this.save();return 'changed';}
 edit(user,id,action){const u=this.user(user),old=u.edits.find(x=>x.id===id);if(old){if(old.action!==action)throw Error('edit id reused with different intent');return 'duplicate';}u.edits.push({id,action,scope:structuredClone(u.sources)});u.revision++;this.save();return 'changed';}
 snapshot(user){return {user,...structuredClone(this.user(user))};}
 publish(snapshot,bank){const u=this.user(snapshot.user);if(u.revision!==snapshot.revision)return false;u.bank=bank;u.publishedRevision=snapshot.revision;this.save();return true;}
 recallBank(user){const u=this.user(user);return u.revision===u.publishedRevision?u.bank:null;}
}
module.exports={Ledger};
