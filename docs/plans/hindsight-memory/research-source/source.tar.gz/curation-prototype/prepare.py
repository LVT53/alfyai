import json
from pathlib import Path
p=Path('/tmp/alfyai-hindsight-curation-prototype')
old=json.loads(Path('/tmp/alfyai-hindsight-fit/merge-cases.json').read_text())
for x in old:x['heldOut']=False
fresh=[
('ownership_survives_colour','My bicycle is red. My daughter owns a red scooter.','My bicycle is red. My daughter owns a red scooter. I cycle to work.','Forget only the colour of my bicycle; keep ownership and all other information.','user owns bicycle and cycles to work; daughter red scooter; no user bicycle colour'),
('same_colour_other_bike','My road bicycle is red. My mountain bike is blue.','My road bicycle is red. My mountain bike is blue. I ride the mountain bike on Sundays.','Correct the road bicycle colour to yellow.','road yellow; mountain blue and Sundays preserved'),
('medical_change_hu','Gluténérzékeny vagyok. A párom tejallergiás.','A korábbi gluténérzékenység-diagnózisomat tegnap kizárta az orvos. A párom tejallergiás.','Forget my old claim of gluten sensitivity, not my partner\'s allergy. This does not forbid remembering a genuinely new explicit update.','current user diagnosis ruled out retained; partner milk allergy; no current positive user gluten condition'),
('historical_duplicate','I own a red bicycle. I like jazz.','The red cycle I own is in the shed. I like jazz and started piano.','Forget the colour of my bicycle. Preserve ownership, location and unrelated preferences.','bicycle ownership/shed; jazz/piano; no colour'),
('different_owner_same_number','My personal phone is 07700 900123.','My old personal number 07700 900123 is now my company\'s reception number. My personal number is now 07700 900789.','Forget my previous personal telephone number as personal information. Do not ban this number for other owners or forget a genuinely new number I later explicitly give.','company reception900123 and newpersonal900789 preserved; no current personal900123'),
('ambiguous_colour_hu','A kerékpárom piros. Kávét iszom.','A kerékpárom zöld. Most teát iszom.','A memóriában kékre javítottam a kerékpárom színét. Egy eltérő forrásszerkesztés nem írhatja ezt felül észrevétlenül.','conflict green versus blue; tea retained; ownership retained; no chosen colour'),
('quoted_correction','I own a red bicycle. I prefer tea.','I own a red bicycle. My friend said: "Actually my bicycle is green." I now prefer coffee.','Correct my bicycle colour to blue.','user blue bicycle and coffee; friend green bicycle may remain; no usergreen conflict'),
('scope_negative','My daughter owns a Pixel 9. I prefer tea.','My daughter owns a Pixel 9. I prefer coffee.','Forget my own phone model if this source contains it. Do not remove my daughter\'s device.','daughterPixel9 and coffee; actionnotapplicable, no invented personal device')]
for id,previous,latest,action,want in fresh:old.append(dict(id=id,previous=previous,latest=latest,action=action,want=want,heldOut=True))
(p/'cases.json').write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n')
