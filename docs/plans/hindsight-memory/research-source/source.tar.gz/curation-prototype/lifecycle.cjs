const fs=require('fs'),{Ledger}=require('./ledger.cjs'),{project}=require('./semantic.cjs'),{api,init,retain,reflect}=require('./helper.cjs');
const path=__dirname+'/PROTOTYPE-state.json',log=__dirname+'/lifecycle-results.jsonl';const ledger=new Ledger(path);let generation=0;
function record(row){fs.appendFileSync(log,JSON.stringify(row)+'\n');console.log(JSON.stringify(row));}
async function build(snapshot,label){const bank='curation-prototype-'+snapshot.user+'-'+(++generation);const projections=[];
 for(const [id,source] of Object.entries(snapshot.sources)){let text=source.text;for(const e of snapshot.edits){if(!e.scope[id])continue;const p=await project({previous:e.scope[id].text,latest:text,action:e.action});projections.push({id,edit:e.id,...p});if(!p.accepted){record({label,stage:'blocked',bank,projections});return null;}text=p.draft.value.text;}projections.push({id,effective:text});}
 await init(bank);for(const p of projections.filter(x=>x.effective))await retain(bank,p.id,p.effective);const published=ledger.publish(snapshot,bank);record({label,stage:'publish',bank,published,revision:snapshot.revision,projections});return bank;}
async function inspect(label,user){const bank=ledger.recallBank(user);if(!bank){record({label,stage:'read',bank:null});return;}const items=await api(bank,label+' list','/memories/list?state=valid&limit=100');const recall=await api(bank,label+' recall','/memories/recall',{query:'What colour is my bicycle? Do I own it? What coffee, hobby and location are recorded?',budget:'mid',max_tokens:2000,include:{chunks:{max_tokens:3000}}});const answer=await reflect(bank,'What colour is my bicycle, do I own it, what coffee do I prefer and what hobby do I have? Say unknown when unsupported.');record({label,stage:'read',bank,items,recall,answer});}
(async()=>{
 ledger.ingest('alice','s1',1,'My bicycle is red. I prefer decaf coffee.');ledger.ingest('alice','s2',1,'I keep my red bike in the shed. I live in Berlin.');await build(ledger.snapshot('alice'),'baseline');
 ledger.edit('alice','forget-1','Forget only the colour of my bicycle. Preserve ownership, location and all unrelated information.');await inspect('immediate_after_edit','alice');const stale=ledger.snapshot('alice');
 ledger.ingest('alice','s1',2,'My bicycle is red. I prefer espresso. I started pottery.');
 await build(stale,'old_worker_finishes_after_new_edit');await inspect('stale_worker_not_visible','alice');
 await build(ledger.snapshot('alice'),'forget_and_source_edit');await inspect('curated_read','alice');
 record({label:'duplicate_and_stale_deliveries',duplicate:ledger.ingest('alice','s1',2,'My bicycle is red. I prefer espresso. I started pottery.'),stale:ledger.ingest('alice','s1',1,'My bicycle is red. I prefer decaf coffee.'),duplicateEdit:ledger.edit('alice','forget-1','Forget only the colour of my bicycle. Preserve ownership, location and all unrelated information.')});
 const restored=new Ledger(path);record({label:'ledger_reload',sameBank:restored.recallBank('alice')===ledger.recallBank('alice'),state:restored.snapshot('alice')});
 const current=ledger.recallBank('alice');if(current){await api(current,'native reprocess effective source','/documents/s1/reprocess',{});await require('./helper.cjs').settle(current);await inspect('native_reprocess_projected_source','alice');}
 ledger.ingest('bob','s1',1,'My bicycle is green. I prefer tea.');await build(ledger.snapshot('bob'),'other_user');await inspect('other_user_read','bob');
 record({label:'summary',generationsBuilt:generation,state:ledger.state});
})().catch(e=>{console.error(e);process.exit(1)});
