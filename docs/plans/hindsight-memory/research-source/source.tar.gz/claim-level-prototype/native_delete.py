from fastapi import APIRouter, Header, HTTPException
from hindsight_api.extensions.http import HttpExtension
from hindsight_api.models import RequestContext

class NativeDelete(HttpExtension):
    def get_router(self, memory):
        router = APIRouter()
        @router.delete('/native-delete/{bank_id}/{memory_id}')
        async def remove(bank_id: str, memory_id: str, authorization: str = Header()):
            if not authorization.startswith('Bearer '):
                raise HTTPException(401)
            ctx = RequestContext(api_key=authorization[7:])
            fact = await memory.get_memory_unit(bank_id=bank_id, memory_id=memory_id, request_context=ctx)
            if fact is None:
                raise HTTPException(404)
            return await memory.delete_memory_unit(memory_id, bank_id=bank_id, request_context=ctx)
        return router
