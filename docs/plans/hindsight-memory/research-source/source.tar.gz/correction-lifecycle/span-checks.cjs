// Mechanical edit guarantees only; no assertion about model semantic correctness.
const assert=require('node:assert/strict');const {apply}=require('./lib.cjs');
assert.equal(apply('owns red kayak; sister owns green kayak',[{find:'red',replace:'purple'}]),'owns purple kayak; sister owns green kayak');
assert.equal(apply('My city: Cork. | Where: Cork',[{find:'My city: Cork',replace:'My city: Galway'},{find:'Where: Cork',replace:'Where: Galway'}]),'My city: Galway. | Where: Galway');
assert.throws(()=>apply('Cork and Cork',[{find:'Cork',replace:'Galway'}]),/nonunique/);
assert.throws(()=>apply('Cork',[{find:'Berlin',replace:'Galway'}]),/missing/);
assert.throws(()=>apply('Cork',[{find:'',replace:'Galway'}]),/nonunique/);
assert.throws(()=>apply('abcdef',[{find:'abc',replace:'x'},{find:'bcde',replace:'y'}]),/overlap/);
assert.equal(apply('private claim',[{find:'private claim',replace:''}]),'');
assert.equal(apply('unchanged fact',[]),'unchanged fact');
console.log('8 mechanical span checks passed; semantic preservation remains model-dependent');
