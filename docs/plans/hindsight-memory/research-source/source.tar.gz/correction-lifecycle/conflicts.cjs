// Two additional native compound-conflict probes, unchanged frozen editing prompt.
const {api,curate,retain,cases,save}=require('./lib.cjs');
const cfg=require('/tmp/alfyai-hindsight-native-quality/common.cjs').config;
const probes=[{...cases[0],id:'conflict_kayaks',changed:'I own a green touring kayak and a white racing kayak. I paddle the touring kayak on Saturdays and it now has a deck compass; the racing kayak is stored at the club.'},{...cases[3],id:'conflict_projects',changed:'My Juniper project uses Scala and ships on Mondays; its new CLI supports offline mode. My Harbor project uses Kotlin and has a dark theme.'}];
save('conflict-frozen.json',probes);
(async()=>{const out=[];for(const c of probes){const bank='cl1-'+c.id;await api(bank,'',{},'PUT');await api(bank,'/config',{updates:{...cfg,enable_observations:true,retain_extraction_mode:'concise'}},'PATCH');await retain(bank,c.changed);out.push({id:c.id,bank,result:await curate(bank,c,c.changed,'third-value-conflict')});save('conflict-results.json',out);console.log(c.id,JSON.stringify(out.at(-1).result.projected))}})().catch(e=>{console.error(e);process.exitCode=1});
