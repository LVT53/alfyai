import asyncio,json
from pathlib import Path
from hindsight_api.extensions.builtin.memory_defense_regex import MemoryDefenseRegexExtension
from hindsight_api.extensions.memory_defense import parse_policy
async def main():
    extension=MemoryDefenseRegexExtension(config={})
    cases=[('bicycle','My bicycle is red. I prefer decaf coffee.'),('bicycle_paraphrase','I ride a red bicycle. I now prefer espresso.'),('shared_condition_hu','A párom és én gluténérzékenyek vagyunk. Szeretem a kerámiázást.'),('personal_and_office_phone','My personal number is +44 7700 900123. The office number is +44 7700 900456.'),('synthetic_secret','My API key is ghp_'+'A'*36+'. I prefer decaf coffee.')]
    rows=[]
    for name,content in cases:
        policy=parse_policy({'enabled':True,'rules':[{'on':'sensitive_data','action':'redact'}]})
        d=await extension.screen(policy=policy,bank_id='synthetic-probe',document_id=name,content=content,tags=[])
        rows.append({'case':name,'source':content,'action':d.action.value,'redacted_content':d.redacted_content,'matched_types':d.matched_types})
    policy=parse_policy({'enabled':True,'rules':[{'on':'forget_bicycle_colour','action':'redact'}]})
    d=await extension.screen(policy=policy,bank_id='synthetic-probe',document_id='unsupported',content=cases[0][1],tags=[])
    rows.append({'case':'unsupported_semantic_detector','action':d.action.value,'redacted_content':d.redacted_content})
    Path(__file__).with_name('defense-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(rows,ensure_ascii=False,indent=2))
asyncio.run(main())
