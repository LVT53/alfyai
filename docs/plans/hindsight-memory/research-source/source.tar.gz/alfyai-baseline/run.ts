// THROWAWAY real AlfyAI memory baseline. No mocked memory/model services.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const scratch='/tmp/alfyai-memory-baseline';
const id=process.argv[2];if(!/^p0[1-6]$/.test(id??''))throw Error('Synthetic profile ID required');
const dbPath=path.join(scratch,id+'.db');if(!path.resolve(dbPath).startsWith(scratch+'/')||fs.existsSync(dbPath))throw Error('Require NEW isolated database');
Object.assign(process.env,{DATABASE_PATH:dbPath,SESSION_SECRET:'synthetic-baseline-only-secret-000000000000',MODEL_1_BASEURL:'http://127.0.0.1:18891/v1',MODEL_1_NAME:'qwen3-6-27b',MODEL_1_API_KEY:'synthetic',MODEL_2_ENABLED:'false',MEMORY_JUDGE_MODEL:'model1',MEMORY_CONSOLIDATION_MODEL:'model1',MEMORY_JUDGE_DRY_RUN:'false',TEI_EMBEDDER_URL:'http://127.0.0.1:18891',TEI_EMBEDDER_MODEL:'qwen3-embedding-4b',TEI_EMBEDDER_API_KEY:'',TEI_RERANKER_URL:'http://127.0.0.1:18891',TEI_RERANKER_API_KEY:'',CONTEXT_SUMMARIZER_URL:'http://127.0.0.1:18891/v1/chat/completions',CONTEXT_SUMMARIZER_API_KEY:'synthetic',CONTEXT_SUMMARIZER_MODEL:'qwen3-6-27b',TZ:'UTC'});
const cases=JSON.parse(fs.readFileSync(scratch+'/cases.json','utf8'));const profile=cases.find((p:any)=>p.id===id);
const RealDate=Date;let virtual=RealDate.parse('2026-09-01T12:00:00Z'),wall=RealDate.now();
class BenchDate extends RealDate {constructor(...args:any[]){super(...(args.length?args:[virtual+RealDate.now()-wall]) as [any]);}static now(){return virtual+RealDate.now()-wall;}}
(globalThis as any).Date=BenchDate;
const clock=(s:string)=>{virtual=RealDate.parse(s);wall=RealDate.now();};
const {db,sqlite}=await import('../../../../src/lib/server/db/index');
const {migrate}=await import('drizzle-orm/better-sqlite3/migrator');migrate(db,{migrationsFolder:path.resolve('drizzle')});
sqlite.function('unixepoch',()=>Math.floor(Date.now()/1000));
if(Math.abs(sqlite.prepare('select unixepoch() as t').get().t-Math.floor(Date.now()/1000))>1)throw Error('Clock mismatch');
const schema=await import('../../../../src/lib/server/db/schema');
const {createConversation}=await import('../../../../src/lib/server/services/conversations');
const {createMessage}=await import('../../../../src/lib/server/services/messages');
const {judgeFinishedTurn}=await import('../../../../src/lib/server/services/memory-judge/dispatch');
const {flushPendingJudgeRuns,sweepDirtyConversations,stopMemoryJudgeRunner}=await import('../../../../src/lib/server/services/memory-judge/runner');
const {countUnjudgedMessages}=await import('../../../../src/lib/server/services/memory-judge/segment');
const {runUserMemoryConsolidation}=await import('../../../../src/lib/server/services/memory-consolidation/index');
const {getMemoryContext}=await import('../../../../src/lib/server/services/memory-context');
const {updateTaskStateCheckpoint}=await import('../../../../src/lib/server/services/task-state');
const {buildConstructedContext}=await import('../../../../src/lib/server/services/chat-turn/context-selection');
const {answer}=await import('./answer.cjs');
await db.insert(schema.users).values({id,email:id+'@example.invalid',passwordHash:'synthetic',uiLanguage:profile.lang,timeZone:'Europe/Dublin',createdAt:new Date(),updatedAt:new Date()});
for(const name of ['cedar','atlas'])await db.insert(schema.projects).values({id:id+'-'+name,userId:id,name:name==='cedar'?'Cedar':'Atlas',createdAt:new Date(),updatedAt:new Date()});
const out:any={id,lang:profile.lang,protocol:'real-alfyai-v1',intake:[],nights:[],checks:[],errors:[]};
const save=()=>fs.writeFileSync(scratch+'/'+id+'-results.json',JSON.stringify(out,null,2));
function snapshot(){return {items:sqlite.prepare('select * from memory_profile_items where user_id = ?').all(id),telemetry:sqlite.prepare("select name from sqlite_master where type='table' and name like 'memory%'").all().map((x:any)=>x.name)};}
const events=[...profile.sessions.map((s:any,i:number)=>({...s,kind:'retain',index:i})),...profile.checks.map((c:any,i:number)=>({...c,kind:'check',index:i}))].sort((a,b)=>a.day.localeCompare(b.day)||(a.kind==='retain'?-1:1));
let lastDay:string|null=null;
try{for(const e of events){if(lastDay&&lastDay!==e.day){for(let d=RealDate.parse(lastDay+'T00:00:00Z');d<RealDate.parse(e.day+'T00:00:00Z');d+=86400000){const day=new RealDate(d).toISOString().slice(0,10);clock(day+'T23:00:00Z');const r=await runUserMemoryConsolidation(id,'synthetic-night');out.nights.push({day,result:r});if(r.status==='failed')out.errors.push({stage:'consolidation',day,result:r});save();}}lastDay=e.day;clock(e.day+'T12:00:00Z');const c=await createConversation(id,'Synthetic '+e.kind+' '+e.index,{projectId:e.project?id+'-'+e.project:null});
if(e.kind==='retain'){const t=RealDate.now();const m=await createMessage(c.id,'user',e.text);let task=null;try{task=await updateTaskStateCheckpoint({userId:id,conversationId:c.id,message:e.text,assistantResponse:'',attachmentIds:[],promptArtifactIds:[],userMessageId:m.id,assistantMessageId:null});}catch(err){out.errors.push({stage:'task',index:e.index,error:String(err)});}const dispatch=await judgeFinishedTurn({userId:id,conversationId:c.id,userMessage:e.text,userMessageId:m.id,assistantMessageId:null,assistantResponse:''});await flushPendingJudgeRuns(id);await sweepDirtyConversations(id);const unjudged=await countUnjudgedMessages({userId:id,conversationId:c.id});if(unjudged)out.errors.push({stage:'unjudged',index:e.index,count:unjudged});out.intake.push({...e,conversationId:c.id,messageId:m.id,dispatch,task,unjudged,ms:RealDate.now()-t,snapshot:snapshot()});console.log(id,'INTAKE',e.index,'unjudged',unjudged);}
else {const t=RealDate.now();const passive=await buildConstructedContext({userId:id,conversationId:c.id,message:e.query,modelId:'model1',attachmentIds:[]});const persona=await getMemoryContext({userId:id,conversationId:c.id,mode:'persona',query:e.query});const project=e.project?await getMemoryContext({userId:id,conversationId:c.id,mode:'project',query:e.query}):null;const evidence={passiveContext:passive.inputValue,persona,project};const answers:any={};for(const arm of (e.index%2?['tool','passive']:['passive','tool']))answers[arm]=await answer(profile,e,arm==='passive'?{context:passive.inputValue}:evidence,'alfyai-'+arm);out.checks.push({...e,conversationId:c.id,passive,persona,project,answers,retrievalAndAnswerMs:RealDate.now()-t,snapshot:snapshot()});console.log(id,'CHECK',e.index,JSON.stringify(answers.tool.text));}save();}
out.finalSnapshot=snapshot();out.complete=true;save();console.log(id,'DONE');}catch(e){out.errors.push({stage:'fatal',error:String(e),stack:(e as Error).stack});save();console.error(e);process.exitCode=1;}finally{stopMemoryJudgeRunner();}
// Let best-effort telemetry/embedding writes settle before closing scratch DB.
await new Promise(r=>setTimeout(r,1000));sqlite.close();
