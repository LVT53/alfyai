// Compatibility presentation split for the pinned native generated suffix format.
// Never choose truth, rewrite statements, or delete arbitrary parentheses.
function splitNativeNotes(row,native){let current=row.text;const notes=[];const raw=new Map(native.items.filter(x=>x.fact_type!=='observation').map(x=>[x.id,x]));const suffixes=(row.source_memory_ids||[]).map(id=>raw.get(id)).filter(f=>f?.mentioned_at).map(f=>({id:f.id,text:'('+f.mentioned_at.slice(0,16).replace('T',' ')+': '+f.text.split(' | ')[0].trim()+')'}));let match;while((match=suffixes.find(s=>current.endsWith(' '+s.text)))){notes.unshift(match);current=current.slice(0,-match.text.length).trimEnd()}return {id:row.id,current,nativeNotes:notes,original:row.text,sourceIds:row.source_memory_ids}}
module.exports=splitNativeNotes;
