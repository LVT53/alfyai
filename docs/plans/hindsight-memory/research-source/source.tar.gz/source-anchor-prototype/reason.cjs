const fs=require('fs'),{project,anchorPrompt,alignPrompt}=require('./anchored.cjs');
const ids=['correct_keep_new_details','forget_keep_new_details','shared_subject_hu','conflicting_target_edit','different_owner_same_number','new_explicit_life_event','ambiguous_colour_hu','same_word_other_owner'];
const cases=[...JSON.parse(fs.readFileSync(__dirname+'/cases.json')).filter(x=>ids.includes(x.id)),...JSON.parse(fs.readFileSync(__dirname+'/fresh-frozen.json')).cases];
fs.writeFileSync(__dirname+'/reason-frozen.json',JSON.stringify({anchorPrompt,alignPrompt,reasoning:true,max_tokens:6000,cases},null,2));
(async()=>{const rows=[];for(const c of cases){let result;try{result=await project(c)}catch(e){result={accepted:false,error:e.message}}rows.push({...c,...result});fs.writeFileSync(__dirname+'/reason-results.json',JSON.stringify(rows,null,2));console.log(c.id,JSON.stringify(rows.at(-1)));}})();
