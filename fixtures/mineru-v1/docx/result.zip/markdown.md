## **ALFA Quarterly Overview**

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

### **BRAVO Methodology**

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

- ECHO first bullet item
- FOXTROT second bullet item
- GOLF third bullet item

### **CHARLIE Results**

| Region | Widgets | Sprockets |
| --- | --- | --- |
| Northland | 120 | 45 |
| Southmoor | 98 | 63 |
| Eastvale | 142 | 31 |

#### **DELTA Limitations**

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

![](images/page_0_image_body_9.jpg)