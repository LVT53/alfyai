## ALFA Quarterly Overview

- ECHO first bullet item
- FOXTROT second bullet item
- GOLF third bullet item

## CHARLIE Results

![](images/page_1_image_body_1.jpg)